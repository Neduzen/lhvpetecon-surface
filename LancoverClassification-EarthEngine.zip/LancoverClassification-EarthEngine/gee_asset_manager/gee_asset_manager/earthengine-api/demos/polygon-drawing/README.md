Earth Engine Demo: Polygon Drawing
==================================

[Live Demo](https://polygon-drawing-dot-ee-demos.appspot.com/)

This example demonstrates how to use polygons drawn on a Google Map with
the Earth Engine JavaScript client library.

To set up, follow the instructions in the Developer Docs to
[deploy an EE-based App Engine app](
    https://developers.google.com/earth-engine/app_engine_intro#deploying-app-engine-apps-with-earth-engine).
For the credentials section, you'll need an OAuth2 Client ID, not a Service Account.
